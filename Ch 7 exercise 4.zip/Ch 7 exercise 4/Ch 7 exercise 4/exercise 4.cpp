// Julian Rivas October 2 2024 ch 7 in class exercise 2

#include <iostream>
using namespace std;

bool magicSquare(int sqr[3][3]) {
    int totalSum = 15;

    int diagonalSum1 = 0;
    int diagonalSum2 = 0;

    for (int i = 0; i < 3; i++) {

        int rowSum = 0;
        int columSum = 0;

        diagonalSum1 += sqr[i][i]; 
        diagonalSum2 += sqr[i][2 - i]; 

        for (int ii = 0; ii < 3; ii++) {

            rowSum += sqr[i][ii]; 
            columSum += sqr[ii][i]; 
        }

       
        if (rowSum != totalSum or columSum != totalSum) {
            return false;
        }
    }

    bool numbers[10] = { false }; 

    for (int i = 0; i < 3; i++) {

        for (int ii = 0; ii < 3; ii++) {
            int singleNumber = sqr[i][ii];
           
            if (singleNumber < 1 && singleNumber > 9 or numbers[singleNumber]) {

                return false;
            }
            numbers[singleNumber] = true;
        }
    }

    return true; 
}

int main() { 
    int sqr[3][3] = { 
                            // Change your numbers here to test the Program for different results
        {4, 9, 2},
        {3, 5, 7},         
        {8, 1, 6}
    };

    if (magicSquare(sqr)) {

        cout << "Your Square is a Lo Shu Magic Square" << endl;
    }

    else {
        cout << "Your Square is  not a Lo Shu Magic Square" << endl;
    }

    return 0; 
}
